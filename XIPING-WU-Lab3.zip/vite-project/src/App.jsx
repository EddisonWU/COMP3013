import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import React from 'react';
import './App.css'
import data from "./data.js";

import PlayButtonList from './PlayButtonList'
import AlbumList from './AlbumList'


function App() {

    
    const [AlbumIndex, updateAlbumIndex] = React.useState(0);
    const album = data?.[AlbumIndex];

    return (
    <div class ="Box-item">
      <div class = "item">
        <img className='imgone' src={album?.coverImg}></img>
      </div>

      <div class = "item">
         <PlayButtonList AlbumIndex={AlbumIndex} />
      </div>

      <div class = "item1">
        <AlbumList updateAlbumIndex={updateAlbumIndex}/>       
      </div>

    </div> 
  );
}

export default App

